<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Mail;
use Illuminate\Support\Facades\Log;
use App\Mail\EmailManager;

class NewsletterController extends Controller
{
    public function __construct()
    {
        $this->middleware(['permission:newsletter'])->only('index');
    }

    public function index(Request $request)
    {
        $users = User::where('user_type','!=','admin')->get();
        return view('admin.marketing.newsletters', compact('users'));
    }

    public function send(Request $request)
    {
        if (env('MAIL_USERNAME') != null) {
            //sends newsletter to selected users
        	if ($request->has('user_emails')) {
                foreach ($request->user_emails as $key => $email) {
                    $array['view'] = 'emails.newsletter';
                    $array['subject'] = $request->subject;
                    $array['from'] = env('MAIL_USERNAME');
                    $array['content'] = $request->content;

                    try {
                        Mail::to($email)->queue(new EmailManager($array));
                    } catch (\Exception $e) {
                        //dd($e);
                    }
            	}
            }
        }
        else {
            flash(translate('Please configure SMTP first'))->error();
            return back();
        }

    	flash(translate('Newsletter has been send'))->success();
    	return redirect()->route('newsletters.index');
    }

    public function testEmail(Request $request)
    {
        $array['view'] = 'emails.newsletter';
        $array['subject'] = 'SMTP Test';
        $array['from'] = env('MAIL_FROM_ADDRESS', env('MAIL_USERNAME'));
        $array['content'] = 'This is a test email.';

        try {
            Mail::to($request->email)->send(new EmailManager($array));
            flash(translate('An email has been sent.'))->success();
        } catch (\Throwable $e) {
            Log::warning('Admin SMTP test email failed.', [
                'email' => $request->email,
                'message' => $e->getMessage(),
            ]);

            flash(translate('SMTP test failed. Please check mail credentials and Laravel logs.'))->error();
        }

        return back();
    }
}
